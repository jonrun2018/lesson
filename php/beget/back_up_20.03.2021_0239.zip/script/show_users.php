<?php

    require_once 'database_connection.php';
    require_once 'view.php';
    require_once 'authorize.php';

    // Создание инструкции SELECT
    $select_users = "SELECT users_id, first_name, last_name, email FROM users";

    // Запуск запроса
    $result = mysqli_query($link, $select_users);

    // Проверка наличия сообщения
    // if (isset($_REQUEST["succes_message"])) {
    //     $msg = $_REQUEST["succes_message"];
    // }

?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/phpMM.css">
    <script>
        function delete_user(user_id) {
            if(confirm("Вы уверены, что хотите удалить этого пользователя?" +
                       "\nВернуть его уже не удастся!")) {
                window.location = "delete_user.php?user_id=" + user_id;               
            }
        }

        // function get_request_param_value(param_name) {
        //     param_name = param_name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        //     let regexS = "[\\?&]" + param_name + "=([^&#]*)"
        //     let regex = new RegExp(regexS);
        //     let results = regex.exec(decodeURI(window.location.href));
        //     if (results == null){
        //         return "";
        //     } else {
        //         return results[1];
        //     }
        // }

        // let msg = get_request_param_value('succes_message');
        // if (msg.length > 0) alert(msg);
    
        <?php
            //if (isset($msg)) {?>
                    //window.onload = function() {
                        // alert("<?php// echo $msg;?>");
                    //};
       <?php //};
        ?>
    </script>
</head> -->

<?php

$delete_user_script = <<<EOD
    function delete_user(user_id) {
        if(confirm("Вы уверены, что хотите удалить этого пользователя? Вернуть его уже не удастся!")) {
            window.location = "delete_user.php?user_id=" + user_id;               
        }
    }
EOD;


page_start("Пользователи", $delete_user_script, $_REQUEST['succes_message'], $_REQUEST['error_message']);

?>
<!-- <body>
    
    <div id="header">
        <h1>PHP & MySQL</h1>
    </div>

    <div id="example">Пользователи</div>

    <?php //display_messages($msg);?> -->

    <div id="content">
        <ul>
            <?php
            
                while( $user = mysqli_fetch_array($result) ){

                    $user_row = sprintf("<li>".
                                            "<a href='show_user.php?user_id=%d'>%s %s</a> ".
                                            "(<a href='%s'>%s</a>) ".
                                            "<a href='javascript: delete_user(%d);'>".
                                                "<img src='/images/delete.png' class='delete_user' width='15px' >".
                                            "</a>".
                                        "</li>",
                                        $user['users_id'], 
                                        $user['first_name'], 
                                        $user['last_name'], 
                                        $user['email'], 
                                        $user['email'],
                                        $user['users_id']
                                    );

                    echo $user_row;

                }
            
            ?>
        </ul>
    </div>

    <div id="footer"></div>

</body>
</html>