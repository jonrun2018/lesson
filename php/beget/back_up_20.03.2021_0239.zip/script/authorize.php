<?php

    require_once "database_connection.php";
    // define(VALID_USERNAME, 'admin');
    // define(VALID_PASWORD, '1234');

    if( 
        !isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
        header('HTTP/1.1 401 Unautorized');
        header('WWW-Authenticate: Basic realm="The Social Site"');
        exit("Пытаешься меня взломать?");
    };
    
    // поиск предоставленных пользователю полномочий
    $query = sprintf("SELECT users_id, username FROM users ".
                    "WHERE username = '%s' AND password = '%s';",
                    mysqli_real_escape_string($link, $_SERVER['PHP_AUTH_USER']),
                    mysqli_real_escape_string($link, $_SERVER['PHP_AUTH_PW'])
    );
    
    $results = mysqli_query($link, $query);

    if(mysqli_num_rows($results) == 1) {
        // все в порядке, пользователь может проходить дальше
        $result = mysqli_fetch_array($results);
        $current_user_id = $result["user_id"];
        $current_user_name = $result["username"];
    } else {
        // все плохо, гоним его от сюда
        header('HTTP/1.1 401 Unautorized');
        header('WWW-Authenticate: Basic realm="The Social Site"');
        exit("Пытаешься меня взломать, козел? Пошел от сюда!");
    }
?>