<?php

    require_once 'database_connection.php';
    require_once 'authorize.php';

    // получение идентификатора удаляемого пользователя
    $user_id = $_REQUEST['user_id'];

    // Создание инструкции delete
    $delete_user = sprintf("DELETE FROM users WHERE users_id = %d", $user_id);

    // удалиние пользователя из базы данных
    mysqli_query($link, $delete_user);

    // Перенаправлшение на show_user.php
    $msg = "Указанный пользователь был удален.";
    header("Location: show_users.php?succes_message={$msg}");
    exit();
?>