<?php

    require_once 'database_connection.php';

    try{
        if( !isset($_REQUEST['image_id'])){
            handle_error("Не указано изображенние для загрузки");
        }

        $image_id = $_REQUEST['image_id'];
        

        $select_query = sprintf('SELECT * FROM images WHERE image_id = %d', $image_id);
        $result = mysqli_query($link, $select_query);
        

        if(mysqli_num_rows($result) == 0) {
            handle_error('Запрошенной изображение нет, смирись', "не найденно изображение с id {$image_id}.");
        }

        $image = mysqli_fetch_array($result);
        

        header('Content-type: '. $image['mime_type']);
        header('Content-length: '. $image['file_size']);
        echo $image['image_data'];
    }
    catch(Exception $exc){
        handle_error("при загруски вашего изображения произошел сбой", "ошибка при загрузки изображения: {$exc->getMessage()}");
    }

?>