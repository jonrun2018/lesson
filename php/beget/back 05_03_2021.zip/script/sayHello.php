<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/phpMM.css">
</head>
<body>

    <div id="header">
        <h1>PHP & MySQL</h1>
    </div>

    <div id="example">Пример</div>

    <div id="content">
        <h1>Привет, <?php echo $_REQUEST['name'];?></h1>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos deserunt odio ipsum saepe dolor. Sint.</p>
    </div>

    <div id="footer"></div>
    
</body>
</html>