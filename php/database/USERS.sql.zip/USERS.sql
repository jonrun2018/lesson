-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Фев 15 2021 г., 19:06
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u97897pq_php`
--

-- --------------------------------------------------------

--
-- Структура таблицы `USERS`
--
-- Создание: Фев 12 2021 г., 17:22
-- Последнее обновление: Фев 15 2021 г., 15:58
--

DROP TABLE IF EXISTS `USERS`;
CREATE TABLE `USERS` (
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `facebook_url` varchar(100) DEFAULT NULL,
  `twitter_handle` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `USERS`
--

INSERT INTO `USERS` (`user_id`, `first_name`, `last_name`, `email`, `facebook_url`, `twitter_handle`) VALUES
(1, 'Mike', 'Greenfield', 'email@mail.ru', 'http://facebook.com/profile.php?id=wqdqw', '@Mike_Green'),
(2, 'Петр', 'Петров', 'petrov@mail.ru', 'petr', '@petr'),
(3, 'Jon', 'smit', 'smit1987@mail.ru', 'smit', '@smit'),
(4, 'Frik', 'Petrov', 'freek@google.com', 'frik', '@frik'),
(5, 'bog', 'ivanov', 'bog@mail.ru', 'bog', '@bog'),
(6, 'Fredy', 'Garvord', 'Gar@mail.ru', 'gar', '@GAr');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
